
package com.rayyannx.ggmp

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class ApiException(
    val status: Int,
    override val message: String
) : Exception(message)

data class LoginResult(
    val username: String,
    val plan: String
)

object RayyannApi {

    private val jsonType =
        "application/json; charset=utf-8".toMediaType()

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    suspend fun login(
        username: String,
        password: String
    ): LoginResult = withContext(Dispatchers.IO) {

        val payload = JSONObject().apply {
            put("username", username.trim())
            put("password", password)
        }

        val url = AppConfig.BASE_URL.trimEnd('/') + "/RayyannX"

        val request = Request.Builder()
            .url(url)
            .header("Accept", "application/json")
            .post(payload.toString().toRequestBody(jsonType))
            .build()

        client.newCall(request).execute().use { response ->

            val text = response.body?.string().orEmpty()

            val body = try {
                JSONObject(text)
            } catch (_: Exception) {
                JSONObject()
            }

            if (!response.isSuccessful ||
                !body.optBoolean("success")
            ) {
                val message = body.optString("message")
                    .ifBlank { "Login gagal (${response.code})" }

                throw ApiException(response.code, message)
            }

            val account = body.optJSONObject("account")
                ?: throw IOException("Data akun tidak ditemukan")

            val isPremium = account.optBoolean("premium", false)

            if (!isPremium) {
                throw IOException("Akun belum berstatus PREMIUM")
            }

            LoginResult(
                username = account.optString("username"),
                plan = "PREMIUM"
            )
        }
    }
}
