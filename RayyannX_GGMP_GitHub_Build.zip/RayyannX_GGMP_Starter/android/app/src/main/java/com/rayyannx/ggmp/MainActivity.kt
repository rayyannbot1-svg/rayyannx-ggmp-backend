
package com.rayyannx.ggmp

import android.content.Intent
import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.launch

private val bg = Color(0xFF10131C)
private val panel = Color(0xFF1C2230)
private val lime = Color(0xFFB5F34D)

data class InstalledApp(
    val name: String,
    val packageName: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            RayyannApp()
        }
    }
}

@Composable
fun RayyannApp() {
    val context = LocalContext.current
    val activity = context as? ComponentActivity

    var username by rememberSaveable { mutableStateOf("") }
    var password by rememberSaveable { mutableStateOf("") }
    var logged by rememberSaveable { mutableStateOf(false) }
    var loading by rememberSaveable { mutableStateOf(false) }
    var error by rememberSaveable { mutableStateOf<String?>(null) }
    var memberName by rememberSaveable { mutableStateOf("") }
    var page by rememberSaveable { mutableStateOf("Mulai Game") }
    var showApps by rememberSaveable { mutableStateOf(false) }

    val selectedApps = remember { mutableStateListOf<InstalledApp>() }
    val scope = rememberCoroutineScope()

    val activateFloatingPanel = {
        if (
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
            !Settings.canDrawOverlays(context)
        ) {
            val permissionIntent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:${context.packageName}")
            )
            context.startActivity(permissionIntent)
        } else {
            val serviceIntent = Intent(
                context,
                FloatingPanelService::class.java
            )

            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(serviceIntent)
                } else {
                    context.startService(serviceIntent)
                }

                Toast.makeText(
                    context,
                    "Floating Panel diaktifkan",
                    Toast.LENGTH_SHORT
                ).show()
            } catch (e: Exception) {
                Toast.makeText(
                    context,
                    "Gagal mengaktifkan panel: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    LaunchedEffect(logged) {
        activity?.requestedOrientation =
            if (logged) ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            else ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = bg,
            surface = panel,
            primary = lime,
            onPrimary = bg
        )
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = bg
        ) {
            if (!logged) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(24.dp),
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "RAYYANNX",
                        color = lime,
                        fontSize = 30.sp,
                        fontWeight = FontWeight.Black
                    )

                    Text(
                        "GGMP • Account Login",
                        color = Color.LightGray
                    )

                    Spacer(Modifier.height(24.dp))

                    OutlinedTextField(
                        value = username,
                        onValueChange = { username = it },
                        label = { Text("Username") },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !loading,
                        singleLine = true
                    )

                    Spacer(Modifier.height(8.dp))

                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("Password") },
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !loading,
                        singleLine = true
                    )

                    error?.let {
                        Spacer(Modifier.height(10.dp))
                        Text(it, color = Color(0xFFFF7777))
                    }

                    Spacer(Modifier.height(16.dp))

                    Button(
                        onClick = {
                            loading = true
                            error = null

                            scope.launch {
                                try {
                                    val result = RayyannApi.login(
                                        username,
                                        password
                                    )

                                    memberName = result.username
                                    logged = true
                                    password = ""
                                } catch (e: ApiException) {
                                    error = e.message
                                } catch (e: Exception) {
                                    error = e.message ?: "Login gagal."
                                } finally {
                                    loading = false
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !loading &&
                            username.isNotBlank() &&
                            password.isNotBlank()
                    ) {
                        if (loading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp
                            )
                        } else {
                            Text("LOGIN")
                        }
                    }

                    Text(
                        "Login diverifikasi oleh server RayyannX.",
                        color = Color.Gray,
                        fontSize = 12.sp
                    )
                }
            } else {
                Column(Modifier.fillMaxSize()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 22.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "Humanoid Team",
                            color = lime,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black
                        )

                        Text(
                            "RAYYANNX GGMP",
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )

                        Text(
                            "PREMIUM • $memberName",
                            color = lime,
                            fontSize = 13.sp
                        )
                    }

                    HorizontalDivider(color = Color.DarkGray)

                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .verticalScroll(rememberScrollState())
                                .padding(20.dp)
                        ) {
                            when (page) {
                                "Mulai Game" -> {
                                    Text(
                                        "My Games",
                                        color = Color.White,
                                        fontSize = 24.sp,
                                        fontWeight = FontWeight.Bold
                                    )

                                    Spacer(Modifier.height(12.dp))

                                    Button(
                                        onClick = { showApps = true }
                                    ) {
                                        Text("+ Tambahkan Game")
                                    }

                                    Spacer(Modifier.height(8.dp))

                                    Button(
                                        onClick = {
                                            activateFloatingPanel()
                                        },
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text("AKTIFKAN FLOATING PANEL")
                                    }

                                    Spacer(Modifier.height(16.dp))

                                    if (selectedApps.isEmpty()) {
                                        Text(
                                            "Belum ada aplikasi. Tekan Tambahkan Game.",
                                            color = Color.LightGray
                                        )
                                    }

                                    selectedApps.forEach { app ->
                                        Card(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(bottom = 14.dp),
                                            colors = CardDefaults.cardColors(
                                                containerColor = panel
                                            )
                                        ) {
                                            Column(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(14.dp),
                                                horizontalAlignment = Alignment.CenterHorizontally
                                            ) {
                                                AppIcon(app.packageName)

                                                Spacer(Modifier.height(8.dp))

                                                Text(
                                                    app.name,
                                                    color = Color.White,
                                                    fontWeight = FontWeight.Bold
                                                )

                                                Spacer(Modifier.height(10.dp))

                                                Button(
                                                    onClick = {
                                                        context.packageManager
                                                            .getLaunchIntentForPackage(
                                                                app.packageName
                                                            )
                                                            ?.let {
                                                                context.startActivity(it)
                                                            }
                                                    },
                                                    modifier = Modifier.fillMaxWidth()
                                                ) {
                                                    Text("MULAI GAME")
                                                }

                                                TextButton(
                                                    onClick = {
                                                        selectedApps.remove(app)
                                                    }
                                                ) {
                                                    Text("Hapus dari My Games")
                                                }
                                            }
                                        }
                                    }
                                }

                                "Pengaturan" -> {
                                    Text(
                                        "Pengaturan",
                                        color = lime,
                                        fontSize = 24.sp,
                                        fontWeight = FontWeight.Bold
                                    )

                                    Spacer(Modifier.height(10.dp))

                                    SettingsLink("Owner: Rayyannkcung")
                                    SettingsLink(
                                        "WhatsApp",
                                        "https://wa.me/6285716365035"
                                    )
                                    SettingsLink("Telegram")
                                    SettingsLink(
                                        "Instagram",
                                        "https://www.instagram.com/rayyannkcung?vrfl=d21oZ3Y2Z3h4eXg="
                                    )
                                    SettingsLink(
                                        "TikTok",
                                        "https://www.tiktok.com/@rayyannkcung"
                                    )
                                    SettingsLink("Versi Aplikasi")
                                    SettingsLink("Tentang RayyannX GGMP")
                                    SettingsLink("Kebijakan Privasi")

                                    Spacer(Modifier.height(10.dp))

                                    Button(
                                        onClick = {
                                            logged = false
                                            memberName = ""
                                            username = ""
                                            password = ""
                                            page = "Mulai Game"
                                            error = null
                                        },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = Color(0xFF9C3333)
                                        )
                                    ) {
                                        Text("KELUAR AKUN")
                                    }
                                }
                            }
                        }
                    }

                    HorizontalDivider(color = Color.DarkGray)

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 5.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        listOf("Mulai Game", "Pengaturan").forEach { item ->
                            TextButton(
                                onClick = { page = item }
                            ) {
                                Text(
                                    item,
                                    color = if (page == item) lime else Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showApps) {
        val pm = context.packageManager

        val launcherIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }

        val apps = remember(showApps) {
            pm.queryIntentActivities(launcherIntent, 0)
                .mapNotNull { info ->
                    val packageName = info.activityInfo.packageName

                    if (packageName == context.packageName) {
                        null
                    } else {
                        InstalledApp(
                            name = info.loadLabel(pm).toString(),
                            packageName = packageName
                        )
                    }
                }
                .distinctBy { it.packageName }
                .sortedBy { it.name.lowercase() }
        }

        AlertDialog(
            onDismissRequest = { showApps = false },
            title = { Text("Pilih Game / Aplikasi") },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 400.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    apps.forEach { app ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    if (selectedApps.none {
                                            it.packageName == app.packageName
                                        }) {
                                        selectedApps.add(app)
                                    }
                                    showApps = false
                                }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                app.name,
                                color = Color.White
                            )
                        }
                    }

                    if (apps.isEmpty()) {
                        Text(
                            "Tidak ada aplikasi yang ditemukan.",
                            color = Color.White
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showApps = false }) {
                    Text("TUTUP")
                }
            },
        
        )

    }
}

@Composable
fun AppIcon(packageName: String) {
    val context = LocalContext.current

    AndroidView(
        factory = {
            ImageView(it).apply {
                layoutParams = android.view.ViewGroup.LayoutParams(
                    72,
                    72
                )
                scaleType = ImageView.ScaleType.FIT_CENTER

                try {
                    setImageDrawable(
                        context.packageManager.getApplicationIcon(packageName)
                    )
                } catch (_: Exception) {
                    setImageResource(android.R.drawable.sym_def_app_icon)
                }
            }
        },
        modifier = Modifier.size(72.dp)
    )
}

@Composable
fun SettingsLink(
    title: String,
    url: String? = null
) {
    val context = LocalContext.current

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp)
            .clickable {
                if (url != null) {
                    try {
                        val intent = Intent(
                            Intent.ACTION_VIEW,
                            Uri.parse(url)
                        )
                        context.startActivity(intent)
                    } catch (_: Exception) {
                        Toast.makeText(
                            context,
                            "Tidak dapat membuka tautan",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                } else {
                    Toast.makeText(
                        context,
                        title,
                        Toast.LENGTH_SHORT
                    ).show()
                }
            },
        colors = CardDefaults.cardColors(
            containerColor = panel
        )
    ) {
        Text(
            text = title,
            color = Color.White,
            modifier = Modifier.padding(16.dp)
        )
    }
}
