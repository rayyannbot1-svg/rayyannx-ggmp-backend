
package com.rayyannx.ggmp

object AppConfig {
    const val BASE_URL =
        "https://tbwacqfvgxlptnldanon.supabase.co/functions/v1/"
}
