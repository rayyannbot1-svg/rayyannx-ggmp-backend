# RayyannX GGMP Backend

Backend Node.js/Express untuk login `Username + Password + License Key` menggunakan Supabase.

## Deploy ke Render

Repository GitHub yang dipakai: `rayyannbot1-svg/rayyannx-ggmp-backend`

- Runtime: Node
- Build command: `npm install`
- Start command: `npm start`
- Environment variables:
  - `SUPABASE_URL` = `https://tbwacqfvgxlptnldanon.supabase.co`
  - `SUPABASE_SECRET_KEY` = Secret Key Supabase (jangan pernah masukkan ke aplikasi Android atau commit ke GitHub)
  - `JWT_SECRET` = string acak rahasia minimal 32 karakter
  - `NODE_ENV` = `production`

Setelah deploy, buka `https://NAMA-SERVICE.onrender.com/health`. Hasil yang benar:
`{"success":true,"status":"ok"}`

Endpoint login: `POST https://NAMA-SERVICE.onrender.com/auth/login`

JSON body:
```json
{
  "username": "namauser",
  "password": "password",
  "licenseKey": "XXXX-XXXX"
}
```

## Catatan penting tentang tabel

Kode mengasumsikan kolom berikut tersedia:

- `users`: `id`, `username`, `password_hash`, `is_active`
- `license_keys`: `id`, `key`, `user_id`, `is_active`, `expires_at`
- `auth_sessions`: `user_id`, `license_key_id`, `token`, `created_at`

Nama kolom tabel yang sudah dibuat sebelumnya belum dapat diverifikasi dari source yang tersedia. Jika berbeda, sesuaikan query di `src/server.js` dengan skema aktual sebelum dipakai.

## Keamanan

- Secret Key hanya di environment variables Render.
- Jangan kirim Secret Key ke chat, APK, atau repository.
- Password disimpan sebagai bcrypt hash, bukan teks biasa.
- JWT_SECRET harus unik dan rahasia.
- Login dibatasi 10 percobaan per 15 menit per alamat IP.
